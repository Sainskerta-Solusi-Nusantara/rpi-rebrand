RPI Logo Pack
=============

Berisi:
- rpi-logo.svg  : wordmark utama (navy + aksen emas)
- rpi-mark.svg  : ikon/mark persegi untuk avatar & favicon

Warna merek:
- Navy  #0A2540
- Emas  #C9A961

Format vektor (SVG) dapat diekspor ke PNG pada resolusi apa pun.
Pertanyaan: hello@rumahpekerja.id
